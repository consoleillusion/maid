#!/usr/bin/env bash
# Everything since maid-tool-ux.zip, as one commit, then loads the
# milestone 2 scoring plan. Unzip into /workspace/maid and run this script.
set -euo pipefail

TRAILER='Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_0175b167pvEqbnfB69ov4C9Y'

main() {
  # Purpose: commit the code, load the plan, and show the status.
  git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "not inside a git repository" >&2; exit 1; }
  git diff --cached --quiet || { echo "the index has staged changes; commit or unstage them first" >&2; exit 1; }
  git add -- cmd/maid/main.go internal/guide/guide.go internal/mcp/server.go internal/mcp/server_test.go internal/mcp/tools.go internal/tasks/beads.go internal/work/designops.go internal/work/files.go internal/work/files_test.go internal/work/packet.go internal/work/queue.go internal/work/service.go internal/work/work_test.go
  if git diff --cached --quiet; then
    echo "skip (no changes): code already committed"
  else
    printf '%s\n\n%s\n' "feat: batch approval, stubs, all tools listed, work through maid

- maid_next asks one question for all chapters waiting for approval;
  design_set_status takes a list of ids; maid accept -pending.
- Tests items own their code item's files, so test agents can add stubs
  that make the tests compile (REQ-WI-022, REQ-WI-023).
- Every tool is listed in every phase; work tools refuse calls before
  phase 5 with the next step (REQ-PH-004).
- work_files, work_read, work_write, work_run and work_commit let an
  agent with no file access complete a work item (REQ-WI-024 to 027).
- work_submit takes a patch or whole files, applies and commits them,
  then runs the merge queue (REQ-WI-028).
- Design writes that change nothing do not try to commit." "$TRAILER" | git commit -q -F -
    echo "committed"
  fi
  echo "loading the milestone 2 plan..."
  nix shell .#maid .#bd -c maid plan plan-m2-score.json
  rm -f plan-m2-score.json
  nix shell .#maid .#bd -c maid status
  echo
  echo "Now fully quit and reopen the Claude desktop app."
}

main "$@"
