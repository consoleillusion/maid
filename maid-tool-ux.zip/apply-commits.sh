#!/usr/bin/env bash
# Makes maid's tools self-explaining. Apply after maid-guide-fix.zip.
# Unzip into the repository root, run ./apply-commits.sh, push yourself.
set -euo pipefail

TRAILER='Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_0175b167pvEqbnfB69ov4C9Y'

main() {
  # Purpose: commit the resolver, ready-to-run calls and local-only Beads.
  git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "not inside a git repository" >&2; exit 1; }
  git diff --cached --quiet || { echo "the index has staged changes; commit or unstage them first" >&2; exit 1; }
  git add -- design/01-foundation/02-glossary.md design/04-architecture/02-task-store.md internal/design/read.go internal/design/write.go internal/guide/guide.go internal/mcp/server.go internal/mcp/server_test.go internal/mcp/tools.go internal/tasks/beads.go internal/design/resolve.go internal/design/resolve_test.go
  if git diff --cached --quiet; then
    echo "skip (no changes): already applied"
    return
  fi
  printf '%s\n\n%s\n' "feat(mcp): make the tools usable without instructions

- Refs accept chapter IDs, file paths, titles, item IDs in any case and
  chapter#heading. Unknown refs return did_you_mean suggestions, and
  design_read returns what it can with the rest in not_found.
- maid_next returns ready-to-run calls with arguments and the question
  to ask the user, such as whether they accept the vision.
- Errors say what to do next; tool descriptions include examples.
- The server instructions say that maid is written in lowercase and that
  the design phases need no file access.
- maid init creates Beads in stealth mode: local only, no Dolt remote,
  .beads/ excluded from git." "$TRAILER" | git commit -q -F -
  echo "commit: feat(mcp): make the tools usable without instructions"
}

main "$@"
